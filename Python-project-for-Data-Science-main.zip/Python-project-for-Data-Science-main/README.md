# Analyzing Historical Stock/Revenue Data Using yfinance lib of Python and Webscraping
yfinance library of python provides a wide range of functionalities to deal with the stock data of a company. this library of python is intended for data scientists so to collect data of various leading companies and to perform data manipulating operations on them.
Webscraping is a process in which we extract our required data from a webite.In this particular project related to Data Science I webscraped required tables into pandas dataframes using pandas library.

